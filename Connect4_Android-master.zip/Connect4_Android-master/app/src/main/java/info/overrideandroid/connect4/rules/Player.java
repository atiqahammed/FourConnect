package info.overrideandroid.connect4.rules;

/**
 * Created by Rahul on 30/05/17.
 *
 */

public class Player {
    public static final int PLAYER1 = 1;//you
    public static final int PLAYER2 = 2;//Ai or friend
}
